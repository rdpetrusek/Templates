﻿using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class ReadOnlyDelegatingHandler : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if(request.Method == HttpMethod.Get)
                return await base.SendAsync(request, cancellationToken);
            
            return new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest)
            {
                RequestMessage = request,
                Content = new StringContent("This endpoint only supports GET requests.")
            };
        }
    }
}